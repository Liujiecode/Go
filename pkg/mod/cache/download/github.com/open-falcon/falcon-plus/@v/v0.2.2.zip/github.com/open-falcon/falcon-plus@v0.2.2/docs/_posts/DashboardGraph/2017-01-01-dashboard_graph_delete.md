---
category: DashboardGraph
apiurl: '/api/v1/dashboard/graph/:id'
title: 'Delete a DashboardGraph'
type: 'DELETE'
sample_doc: 'dashboard.html'
layout: default
---

* [Session](#/authentication) Required

### Response

```Status: 200```

```{"message":"ok"}```

For errors responses, see the [response status codes documentation](#/response-status-codes).
