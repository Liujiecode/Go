# Documentations

- [Installation and Usage](http://book.open-falcon.com)
- [Open-Faclon API](http://api.open-falcon.com)
