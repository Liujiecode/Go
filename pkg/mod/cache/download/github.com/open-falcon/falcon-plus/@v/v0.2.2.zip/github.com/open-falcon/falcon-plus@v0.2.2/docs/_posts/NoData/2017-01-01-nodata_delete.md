---
category: NoData
apiurl: '/api/v1/nodata/#{nodata_id}'
title: "Delete Nodata"
type: 'DELETE'
sample_doc: 'nodata.html'
layout: default
---

* [Session](#/authentication) Required
* ex. /api/v1/nodata/4

### Response

```Status: 200```
```{"message":"mockcfg:4 is deleted"}```
