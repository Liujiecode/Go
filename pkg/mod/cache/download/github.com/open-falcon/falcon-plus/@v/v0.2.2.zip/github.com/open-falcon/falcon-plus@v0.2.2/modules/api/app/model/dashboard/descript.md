* A map item -many-> screen items [on dashboard_screen] {id <-> pid}
* A screen -many-> graphs [dashboard_screen <-> dashboard_graph] {id <-> screen_id}
