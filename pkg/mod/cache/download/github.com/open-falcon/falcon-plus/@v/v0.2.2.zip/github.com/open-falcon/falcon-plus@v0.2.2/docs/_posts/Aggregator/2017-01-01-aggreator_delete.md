---
category: Aggregator
apiurl: '/api/v1/aggregator/16'
title: "Delete Aggregator"
type: 'DELETE'
sample_doc: 'aggregator.html'
layout: default
---

* [Session](#/authentication) Required

### Response

```Status: 200```
```{"message":"aggregator:16 is deleted"}```
