Ask questions at
[StackOverflow](https://stackoverflow.com/questions/ask?tags=go+redis).

[Open an issue](https://github.com/garyburd/redigo/issues/new) to discuss your
plans before doing any work on Redigo.
